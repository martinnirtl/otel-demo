const opentelemetry = require('@opentelemetry/api');
const { BasicTracerProvider } = require('@opentelemetry/tracing');
// const { CounterMetric } = require('@opentelemetry/metrics');
const express = require('express');
const axios = require('axios').default;

const tracerProvider = new BasicTracerProvider();
tracerProvider.register();

const tracer = opentelemetry.trace.getTracer();

const app = express();

app.use(express.json());

app.get('/', (req, res) => res.send('Hello World!'));

app.post('/subscribe', async (req, res) => {
  const sendConfirmationEmailSpan = tracer.startSpan('sendConfirmationEmail', {  attributes: req.body });

  try {
    console.log('rendering the email template');

    const emailContent = {
      to: req.body.email,
      subject: 'Welcome to our newsletter!',
      text: `Hi ${req.body.email},\nThanks for subscribing to our newsletter! Expect crazy interesting news and updates.\n\nSoon in your inbox!\n\nCiao,\nYour Service team`
    };

    console.log('sending the email');

    await axios.get(`${process.env.MAIL_SERVICE_BASE_URL}/send`, emailContent);
  
  } catch (error) {
    console.error(error);

    return res.status(500).send();
  }

  sendConfirmationEmailSpan.end();

  console.log('confirmation email sent');

  return res.status(204).send();
});

const port = process.env.PORT || 3000;

app.listen(port, () => console.log(`listening on port ${port}`));