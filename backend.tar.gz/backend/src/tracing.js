const opentelemetry = require('@opentelemetry/api');
const { BasicTracerProvider } = require('@opentelemetry/tracing');

const tracerProvider = new BasicTracerProvider();
tracerProvider.register();