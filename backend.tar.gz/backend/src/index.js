const opentelemetry = require('@opentelemetry/api');
// const { CounterMetric } = require('@opentelemetry/metrics');
const express = require('express');
const axios = require('axios').default;
const http = require('http');

const tracer = opentelemetry.trace.getTracer();

const app = express();

app.use(express.json());

app.get('/', (req, res) => res.send('Hello World!'));

app.post('/subscribe', async function(req, res) {
  const sendConfirmationEmailSpan = tracer.startSpan('sendConfirmationEmail', { attributes: req.body });
  const ctx = opentelemetry.trace.setSpan(opentelemetry.context.active(), sendConfirmationEmailSpan);

  try {
    console.log('rendering the email template');

    // const buildPayloadSpan = tracer.startSpan('build payload');
    const buildPayloadSpan = tracer.startSpan('build payload', null, ctx);
    const emailContent = {
      to: req.body.email,
      subject: 'Welcome to our newsletter!',
      text: `Hi ${req.body.email},\nThanks for subscribing to our newsletter! Expect crazy interesting news and updates.\n\nSoon in your inbox!\n\nCiao,\nYour Service team`
    };
    buildPayloadSpan.end();

    console.log('sending the email');

    if (req.body.error) {
      throw new Error('Failed to send email.');
    }

    const { data } = await axios.get(`https://httpbin.org/headers`, emailContent);
    console.log(data.headers);
    // await axios.get(`${process.env.MAIL_SERVICE_BASE_URL}/send`, emailContent);

    sendConfirmationEmailSpan.addEvent('send', emailContent);
    sendConfirmationEmailSpan.setStatus({
       code: opentelemetry.SpanStatusCode.OK,
    });
    sendConfirmationEmailSpan.end();

    console.log('confirmation email sent');

    return res.status(204).send();
  } catch (error) {
    console.error(error);

    sendConfirmationEmailSpan.setStatus({
      code: opentelemetry.SpanStatusCode.ERROR,
      message: error.message
    });
    sendConfirmationEmailSpan.end();
    
    return res.status(500).send();
  }
});

const port = process.env.PORT || 3000;

const server = app.listen(port, () => console.log(`listening on port ${port}`));

process.on("SIGINT", () => {
  console.log('received a SIGINT signal. going down...')

  server.close()
});